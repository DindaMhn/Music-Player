package com.example.ktn_ak06c01.viewmodel

class Music(name:String,title:String,image:String){
    var name = name
    var title = title
    var image = image
}